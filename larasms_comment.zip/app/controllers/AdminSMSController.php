<?php

class AdminSMSController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		return View::make('admin.sms.index');
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		// if(Input::get('category_id') == 0)
		// 	return Redirect()->back()->withMessage('Invalid category id');
		
		$categories = Category::lists('title', 'id');
		$users = User::where('id', '>', 0)->get();
		return View::make('admin.sms.create')->with('categories', $categories)->with('users', $users);
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		/*if(Input::get('category_id') == 0)
			return Redirect()->back()->withMessage('Invalid category id');

		if(Input::get('user_id') == 0)
			return Redirect()->back();*/

		Sms::create([
			'category_id' => Input::get('category_id'),
			'user_id' => Input::get('user_id'),
			'title' => Input::get('title'),
			'slug' => Str::slug(Input::get('title')),
			'sms_content' => Input::get('sms_content')
		]);

		return Redirect::route('admin.sms.index')->withMessage('Your SMS has been added');
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}


}
