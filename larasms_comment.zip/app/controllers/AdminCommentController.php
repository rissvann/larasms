<?php

class AdminCommentController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$comments = Comment::get();
		return View::make('admin.comment.index')->with('comments', $comments);
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		$smses = Sms::lists('title', 'id');
		$users = User::where('id', '>', 0)->get();
		return View::make('admin.comment.create')->with('smses', $smses)->with('users', $users);
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
			Comment::create([
			'sms_id' => Input::get('sms_id'),
			'user_id' => Input::get('user_id'),
			'comment_content' => Input::get('comment_content'),
			'comment_status' => 'pending'
		]);

		return Redirect::route('admin.comment.index')->withMessage('Your Content has been added');
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$comment = Comment::find($id);

		return View::make('admin.comment.edit')->with('comment', $comment);
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$comment = Comment::find($id);

		$comment->update([
			'comment_content' => Input::get('comment_content'),
		]);

		return Redirect::route('admin.comment.index')->withMessage('Your comment has been updated.');
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Comment::find($id)->delete();

		return Redirect::route('admin.comment.index')->withMessage('Your comment has been deleted.');
	}


}
