<?php

use Faker\Factory as Faker;

class SmsTableSeeder extends Seeder {

    public function run()
    {
        $faker = Faker::create();

        foreach(range(1, 100) as $index)
        {
            $userId = rand(1,11);
            $categoryId = rand(1,25);
            $title = $faker->sentence(rand(5, 15));

            Sms::create([
            	'category_id' => $categoryId,
            	'user_id' => $userId,
                'title' => $title,
                'slug' => Str::slug($title),
                'sms_content' => $faker->paragraph( rand(5, 15) ),
                'views' => $faker->numberBetween(1, 999)
            ]);
        }
    }

}