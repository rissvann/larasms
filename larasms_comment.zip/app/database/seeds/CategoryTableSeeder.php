<?php

use Faker\Factory as Faker;

class CategoryTableSeeder extends Seeder {

    public function run()
    {
        $faker = Faker::create();

        foreach(range(1, 25) as $index)
        {
            $title = $faker->sentence(rand(2, 6));
            Category::create([
            	'title' => $title,
            	'slug' => Str::slug($title)
            ]);
        }
    }

}