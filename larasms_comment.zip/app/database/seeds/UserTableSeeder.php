<?php

use Faker\Factory as Faker;

class UserTableSeeder extends Seeder {

    public function run()
    {
        $faker = Faker::create();

        User::create([
        	'name' => 'Administrator',
        	'email' => 'admin@admin.com',
        	'password' => Hash::make('abc123')
        ]);

        foreach(range(1, 10) as $index)
        {
            User::create([
            	'name' => $faker->name,
            	'email' => $faker->safeEmail,
            	'password' => Hash::make('abc123')
            ]);
        }
    }

}