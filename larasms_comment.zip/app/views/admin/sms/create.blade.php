@extends('admin.layouts.master')

@section('content')
    <h1 class="page-header">SMSes <a href="{{ route('admin.sms.create') }}" class="btn btn btn-primary">Add New</a></h1>
    {{ Form::open(['route' => 'admin.sms.store', 'method' => 'POST']) }}
    <div class="form-group">
        <label for="category_id">Category</label>
        {{ Form::select('category_id', [0 => '- Select Category -'] + $categories, null , ['class' => 'form-control']) }}
    </div>
    <div class="form-group">
        <label for="user_id">User</label>
        <select name="user_id" id="user_id" class="form-control">
            <option value="0">- Select User -</option>
            @foreach($users as $user)
                <option value="{{ $user->id }}">{{ $user->name }}</option>
            @endforeach
        </select>
    </div>
    <div class="form-group">
        <label for="title">Title</label>
        <input type="text" class="form-control" id="title" name="title">
    </div>
    <div class="form-group">
        <label for="sms_content">SMS Text</label>
        <textarea name="sms_content" id="sms_content" rows="5" class="form-control"></textarea>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
    {{ Form::close() }}
@endsection