@extends('admin.layouts.master')

@section('content')
    <h1 class="page-header">SMSes <a href="{{ route('admin.sms.create') }}" class="btn btn btn-primary">Add New</a></h1>
    @if(Session::has('message'))
        <div class="alert alert-success">
            {{ Session::get('message') }}
        </div>
    @endif
@endsection