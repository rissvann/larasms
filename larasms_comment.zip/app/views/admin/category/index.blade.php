@extends('admin.layouts.master')

@section('content')
    <h1 class="page-header">Categories <a href="{{ route('admin.category.create') }}" class="btn btn btn-primary">Add New</a></h1>
    @if(Session::has('message'))
        <div class="alert alert-success">
            {{ Session::get('message') }}
        </div>
    @endif
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>Title</th>
                <th>Slug</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            @foreach($categories as $category)
                <tr>
                    <td>{{ $category->id }}</td>
                    <td>{{ $category->title }}</td>
                    <td>{{ $category->slug }}</td>
                    <td>
                        {{ Form::open(['route' => ['admin.category.destroy', $category->id], 'method' => 'DELETE']) }}
                        <a href="{{ route('admin.category.edit', $category->id) }}" class="btn btn-info btn-xs">
                            <i class="glyphicon glyphicon-edit"></i>
                        </a>
                        <button type="submit" class="btn btn-danger btn-xs">
                            <i class="glyphicon glyphicon-trash"></i>
                        </button>
                        {{ Form::close() }}
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
@endsection