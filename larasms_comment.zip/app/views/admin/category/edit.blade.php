@extends('admin.layouts.master')

@section('content')
    <h1 class="page-header">Edit Category</h1>
    {{ Form::open(['route' => ['admin.category.update', $category->id], 'method' => 'PUT']) }}
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" id="title" name="title" value="{{ $category->title }}">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
    {{ Form::close() }}
@endsection