@extends('admin.layouts.master')

@section('content')
    <h1 class="page-header">Categories <a href="{{ route('admin.category.create') }}" class="btn btn btn-primary">Add New</a></h1>
    {{ Form::open(['route' => 'admin.category.store', 'method' => 'POST']) }}
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" id="title" name="title" placeholder="Email">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
    {{ Form::close() }}
@endsection