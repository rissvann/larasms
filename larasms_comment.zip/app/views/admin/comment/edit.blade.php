@extends('admin.layouts.master')

@section('content')
    <h1 class="page-header">Edit Comment</h1>
    {{ Form::open(['route' => ['admin.comment.update', $comment->id], 'method' => 'PUT']) }}
        <div class="form-group">
            <label for="comment_content">Comment</label>
            <input type="text" class="form-control" id="comment_content" name="comment_content" value="{{ $comment->comment_content }}">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
    {{ Form::close() }}
@endsection