@extends('admin.layouts.master')

@section('content')
    <h1 class="page-header">Comments <a href="{{ route('admin.comment.create') }}" class="btn btn btn-primary">Add New</a></h1>
    @if(Session::has('message'))
        <div class="alert alert-success">
            {{ Session::get('message') }}
        </div>
    @endif

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>SMS ID</th>
                <th>User ID</th>
                <th>Comment</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            @foreach($comments as $comment)
                <tr>
                    <td>{{ $comment->id }}</td>
                    <td>{{ $comment->sms_id }}</td>
                    <td>{{ $comment->user_id }}</td>
                    <td>{{ $comment->comment_content }}</td>

                    <td>
                        {{ Form::open(['route' => ['admin.comment.destroy', $comment->id], 'method' => 'DELETE']) }}
                        <a href="{{ route('admin.comment.edit', $comment->id) }}" class="btn btn-info btn-xs">
                            <i class="glyphicon glyphicon-edit"></i>
                        </a>
                        <button type="submit" class="btn btn-danger btn-xs">
                            <i class="glyphicon glyphicon-trash"></i>
                        </button>
                        {{ Form::close() }}
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
@endsection