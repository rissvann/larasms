@extends('admin.layouts.master')

@section('content')
    <h1 class="page-header">Comments <a href="{{ route('admin.comment.create') }}" class="btn btn btn-primary">Add New</a></h1>
    {{ Form::open(['route' => 'admin.comment.store', 'method' => 'POST']) }}
    <div class="form-group">
        <label for="sms_id">SMS ID</label>
        {{ Form::select('sms_id', [0 => '- Select SMS -'] + $smses, null , ['class' => 'form-control']) }}
    </div>
    <div class="form-group">
        <label for="user_id">User ID</label>
        <select name="user_id" id="user_id" class="form-control">
            <option value="0">- Select User -</option>
            @foreach($users as $user)
                <option value="{{ $user->id }}">{{ $user->name }}</option>
            @endforeach
        </select>
    </div>
    
    <div class="form-group">
        <label for="sms_content">Comment</label>
        <textarea name="comment_content" id="comment_content" rows="5" class="form-control"></textarea>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
    {{ Form::close() }}
@endsection