<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

/*Route::get('/', function()
{
	$categories = Category::with('smses.user')->get();

	foreach($categories as $cateogry)
	{
		// echo "<h3>" . $cateogry->title . "</h3>";
		echo sprintf("<h3>%s</h3>\n\r", $cateogry->title);

		foreach($cateogry->smses as $sms)
		{
			//echo "<p>" . $sms->title . " (". $sms->views . ") <br> <span style='font-size: 11px;'>" . $sms->user->name . "</span></p>";
			echo sprintf("<p>%s (%d) <br><span style='font-size: 11px;'>%s</span></p>\n\r", $sms->title, $sms->views, $sms->user->name);
		}

		echo "<hr>";
	}
});*/


Route::group(['prefix' => 'admin'], function() {

	Route::resource('category', 'AdminCategoryController');
	Route::resource('sms', 'AdminSMSController');
	Route::resource('comment', 'AdminCommentController');
});
