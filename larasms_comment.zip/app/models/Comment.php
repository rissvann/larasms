<?php

class Comment extends Eloquent {

	protected $fillable = [
		'sms_id', 'user_id', 'comment_content', 'comment_status'
	];

	protected $table = 'comment';

	public function sms()
	{
		return $this->belongsTo('Sms');
	}

	public function user()
	{
		return $this->belongsTo('User');
	}

}
