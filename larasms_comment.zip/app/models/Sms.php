<?php

class Sms extends Eloquent {

	protected $fillable = [
		'category_id', 'user_id', 'title', 'slug', 'sms_content', 'sms_status',
		'views'
	];

	protected $table = 'sms';

	public function category()
	{
		return $this->belongsTo('Category');
	}

	public function user()
	{
		return $this->belongsTo('User');
	}

}
