<?php

class Category extends Eloquent {

	protected $fillable = [
		'title', 'slug'
	];

	protected $table = 'category';

	public function smses()
	{
		return $this->hasMany('Sms');
	}

}
